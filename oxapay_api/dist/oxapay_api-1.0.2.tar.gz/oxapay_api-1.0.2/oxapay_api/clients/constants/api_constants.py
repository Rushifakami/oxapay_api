_GENERAL_API_URL = 'https://api.oxapay.com/'
_METHODS = ['POST']